import TaskManagement from "./component/Task";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./component/Home";
import Taskapi from "./component/Taskapi";
import Filter from "./component/Filter";

import 'animate.css';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" exact element={<Home />} />
        <Route path="/task-management" element={<TaskManagement />} />
        <Route path="/filter" element={<Filter />} />
        <Route path="/task-management-api" element={<Taskapi />} />
      </Routes>
    </Router>


        
  );
}

export default App;
