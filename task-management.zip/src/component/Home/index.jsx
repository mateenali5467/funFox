import { Link } from "react-router-dom";

import Button from "../../ButtonCmp";

const Home = () => {

     const myFunction = () => {
        alert("Button was clicked!");
      };
    
    return (
       <>

<Button theme="primary" onClick={myFunction}>Click me</Button>
       
       <div className="h-screen w-screen bg-gradient-to-r from-blue-400 to-purple-500 flex flex-col justify-center items-center space-y-4">
            <h1 className="text-4xl text-white">Task Management</h1>
           <div>
           <Link to="task-management" className="px-8 py-3 bg-yellow-500 hover:bg-yellow-700 text-blue-900 hover:text-black font-bold rounded-full text-2xl">
                Start Managing Tasks
            </Link>
            <Link to="task-management-api" className="px-8 py-3 bg-yellow-500 hover:bg-yellow-700 text-blue-900 hover:text-black font-bold rounded-full text-2xl">
                Start Managing Tasks api
            </Link>
           </div>

           <h1 className="text-4xl text-white">Mateen Ali</h1>

           
        </div>


       </>
    );
}

export default Home;
