import {useEffect,useState} from 'react';
import {useDispatch, useSelector} from 'react-redux';
import { GetPost } from '../../slices/postSlice';  //import async function from slice


const Taskapi = ()=>{

    const dispatch = useDispatch();
    const {post} = useSelector(response=>response);

    useEffect(()=>{
        dispatch(GetPost())
    },[]);

    const [selectedDay, setSelectedDay] = useState('');
    const [selectedTime, setSelectedTime] = useState('');
  
    const handleDayChange = (e) => {
      setSelectedDay(e.target.value);
    };
  
    const handleTimeChange = (e) => {
      setSelectedTime(e.target.value);
    };
  
    const isRowSelected = (day, time) => {
      return selectedDay === day && selectedTime === time;
    };

    const rows = [
        { day: 'Monday', time: '9AM' },
        { day: 'Monday', time: '10AM' },
        { day: 'Monday', time: '11AM' },
        { day: 'Monday', time: '12PM' },
        { day: 'Monday', time: '1PM' },
        { day: 'Monday', time: '2PM' },
        { day: 'Monday', time: '3PM' },
        { day: 'Monday', time: '4PM' },
        { day: 'Monday', time: '5PM' },
        
        { day: 'Tuesday', time: '9AM' },
        { day: 'Tuesday', time: '10AM' },
        { day: 'Tuesday', time: '11AM' },
        { day: 'Tuesday', time: '12PM' },
        { day: 'Tuesday', time: '1PM' },
        { day: 'Tuesday', time: '2PM' },
        { day: 'Tuesday', time: '3PM' },
        { day: 'Tuesday', time: '4PM' },
        { day: 'Tuesday', time: '5PM' },
      
        { day: 'Wednesday', time: '9AM' },
        { day: 'Wednesday', time: '10AM' },
        { day: 'Wednesday', time: '11AM' },
        { day: 'Wednesday', time: '12PM' },
        { day: 'Wednesday', time: '1PM' },
        { day: 'Wednesday', time: '2PM' },
        { day: 'Wednesday', time: '3PM' },
        { day: 'Wednesday', time: '4PM' },
        { day: 'Wednesday', time: '5PM' },
      
        { day: 'Thursday', time: '9AM' },
        { day: 'Thursday', time: '10AM' },
        { day: 'Thursday', time: '11AM' },
        { day: 'Thursday', time: '12PM' },
        { day: 'Thursday', time: '1PM' },
        { day: 'Thursday', time: '2PM' },
        { day: 'Thursday', time: '3PM' },
        { day: 'Thursday', time: '4PM' },
        { day: 'Thursday', time: '5PM' },
      
        { day: 'Friday', time: '9AM' },
        { day: 'Friday', time: '10AM' },
        { day: 'Friday', time: '11AM' },
        { day: 'Friday', time: '12PM' },
        { day: 'Friday', time: '1PM' },
        { day: 'Friday', time: '2PM' },
        { day: 'Friday', time: '3PM' },
        { day: 'Friday', time: '4PM' },
        { day: 'Friday', time: '5PM' },
      
        { day: 'Saturday', time: '9AM' },
        { day: 'Saturday', time: '10AM' },
        { day: 'Saturday', time: '11AM' },
        { day: 'Saturday', time: '12PM' },
        { day: 'Saturday', time: '1PM' },
        { day: 'Saturday', time: '2PM' },
        { day: 'Saturday', time: '3PM' },
        { day: 'Saturday', time: '4PM' },
        { day: 'Saturday', time: '5PM' },
      
        { day: 'Sunday', time: '9AM' },
        { day: 'Sunday', time: '10AM' },
        { day: 'Sunday', time: '11AM' },
        { day: 'Sunday', time: '12PM' },
        { day: 'Sunday', time: '1PM' },
        { day: 'Sunday', time: '2PM' },
        { day: 'Sunday', time: '3PM' },
        { day: 'Sunday', time: '4PM' },
        { day: 'Sunday', time: '5PM' },
      ];
      
    return (
        <>

  <div className="App">
      <label>
        Select Day:
        <select onChange={handleDayChange}>
          <option value="Monday">Monday</option>
          <option value="Tuesday">Tuesday</option>
          <option value="Wednesday">Wednesday</option>
          <option value="Thursday">Thursday</option>
          <option value="Friday">Friday</option>
          <option value="Saturday">Saturday</option>
          <option value="Sunday">Sunday</option>
        </select>
      </label>
      
      <label>
        Select Time:
        <select onChange={handleTimeChange}>
          <option value="9AM">9AM</option>
          <option value="10AM">10AM</option>
          <option value="11AM">11AM</option>
          <option value="12PM">12PM</option>
          <option value="1PM">1PM</option>
          <option value="2PM">2PM</option>
          <option value="3PM">3PM</option>
          <option value="4PM">4PM</option>
          <option value="5PM">5PM</option>
          <option value="6PM">6PM</option>
        </select>
      </label>

      <table>
        <tbody>
          {rows.map((row, index) => (
            <tr
              key={index}
              style={isRowSelected(row.day, row.time) ? { backgroundColor: 'lightblue' } : {}}
            >
              <td>{row.day}</td>
              <td>{row.time}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>

    {/* Post loading */}
            {
                post.loading && 
                <div className="flex items-center justify-center bg-yellow-50 min-h-screen">
                    <h1 className="text-lg font-semibold">Loading....</h1>
                </div>
            }
            {
                (post.loading === false && post.data) && 
                <div className="flex items-center bg-yellow-50 min-h-screen flex-col gap-y-8 p-8 md:px-0 md:py-16">
                    {
                        post.data.map((item,index)=>(
                            <div key={index} className="animate__animated animate__fadeIn p-5 bg-white rounded-lg shadow-lg md:w-3/4">
                                <h1 className="text-2xl font-semibold capitalize">{item.title}</h1>
                                <p className="text-slate-500">{item.body}</p>
                            </div>
                        ))
                    }
                </div>
            }
            {
                (post.loading === false && post.error) && 
                <div className="flex items-center justify-center bg-yellow-50 min-h-screen">
                    <h1 className="text-lg font-semibold">Something is not right</h1>
                </div>
            }
        </>
    )
}
export default Taskapi;