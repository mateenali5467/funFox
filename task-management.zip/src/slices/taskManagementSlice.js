import { createSlice } from '@reduxjs/toolkit';


const initialState = [];


const tasksSlice = createSlice({
  name: 'tasks',
  initialState,
  reducers: {
    addTask: (state, action) => {
      const { id, title, description, groupId } = action.payload;
      state.push({ id, title, description, completed: false, groupId });
    },
    deleteTask: (state, action) => {
      const id = action.payload;
      return state.filter(task => task.id !== id);
    },
    toggleComplete: (state, action) => {
      const id = action.payload;
      const task = state.find(task => task.id === id);
      if (task) {
        task.completed = !task.completed;
      }
    },
  },
});

export const { addTask, deleteTask, toggleComplete } = tasksSlice.actions;

export default tasksSlice.reducer;
