import { configureStore,combineReducers } from '@reduxjs/toolkit';

import taskManagementSlice from '../slices/taskManagementSlice';
import postSlice from '../slices/postSlice';

import { persistStore, persistReducer } from 'redux-persist';

import storage from 'redux-persist/lib/storage';

const persistConfig = {
    key: 'root',
    storage,
  };

  const rootReducer = combineReducers({
    tasks: taskManagementSlice,
    post  : postSlice
  });

  const persistedReducer = persistReducer(persistConfig, rootReducer);


const store = configureStore({
  reducer: persistedReducer,
});


export const persistor = persistStore(store);
export default store;
